#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
BUILD_TYPE="${BUILD_TYPE:-Release}"
JOBS="${JOBS:-$(nproc)}"
EMP_PREFIX="${EMP_TOOL_ROOT:-$HOME/libs}"
CLEAN_BUILD="${CLEAN_BUILD:-1}"

export EMP_TOOL_ROOT="$EMP_PREFIX"
export CMAKE_PREFIX_PATH="${CMAKE_PREFIX_PATH:-$EMP_PREFIX}"
export LD_LIBRARY_PATH="$EMP_PREFIX/lib:${LD_LIBRARY_PATH:-}"

if [ "$CLEAN_BUILD" = "1" ]; then
  rm -rf "$ROOT/build" "$ROOT/picogram/build" "$ROOT/picogram_imp/build"
fi

echo "[build] root garbled-merge benchmark"
cmake -S "$ROOT" -B "$ROOT/build" \
  -DCMAKE_BUILD_TYPE="$BUILD_TYPE" \
  -DEMP_TOOL_ROOT="$EMP_PREFIX" \
  -DCMAKE_PREFIX_PATH="$CMAKE_PREFIX_PATH"
cmake --build "$ROOT/build" -j"$JOBS"

if [ ! -e "$ROOT/picogram/googletest/CMakeLists.txt" ]; then
  rm -f "$ROOT/picogram/googletest"
  ln -s ../picogram_imp/googletest "$ROOT/picogram/googletest"
fi

for project in picogram picogram_imp; do
  echo "[build] $project"
  cmake -S "$ROOT/$project" -B "$ROOT/$project/build" \
    -DCMAKE_BUILD_TYPE="$BUILD_TYPE" \
    -DCMAKE_PREFIX_PATH="$CMAKE_PREFIX_PATH" \
    -Demp-tool_DIR="$EMP_PREFIX/cmake"
  cmake --build "$ROOT/$project/build" -j"$JOBS"
done

echo "[build] complete"
