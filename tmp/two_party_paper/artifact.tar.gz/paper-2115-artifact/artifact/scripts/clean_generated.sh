#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"

rm -rf \
  "$ROOT/build" \
  "$ROOT/CMakeFiles" \
  "$ROOT/.vscode" \
  "$ROOT/picogram/build" \
  "$ROOT/picogram_imp/build" \
  "$ROOT/artifact_results" \
  "$ROOT/benchmark_results_full" \
  "$ROOT/benchmark_results_imp_partial" \
  "$ROOT/benchmark_results_picogram_partial" \
  "$ROOT/__pycache__" \
  "$ROOT/venv"

find "$ROOT" -name '__pycache__' -type d -prune -exec rm -rf {} +
find "$ROOT" -name '*.pyc' -type f -delete
find "$ROOT" -name '*.bin' -type f -delete
find "$ROOT" -type f \( \
  -name '*.log' -o \
  -name '*.csv' -o \
  -name '*.png' \
\) -delete
rm -f "$ROOT/picogram_imp/rebuttal.txt"
rm -f "$ROOT/swap.sh"

echo "[clean] generated files removed"
