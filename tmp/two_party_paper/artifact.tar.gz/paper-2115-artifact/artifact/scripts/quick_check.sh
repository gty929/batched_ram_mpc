#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
EMP_PREFIX="${EMP_TOOL_ROOT:-$HOME/libs}"

export EMP_TOOL_ROOT="$EMP_PREFIX"
export CMAKE_PREFIX_PATH="${CMAKE_PREFIX_PATH:-$EMP_PREFIX}"
export LD_LIBRARY_PATH="$EMP_PREFIX/lib:${LD_LIBRARY_PATH:-}"

"$ROOT/artifact/scripts/build_all.sh"

"$ROOT/picogram/build/test_basic" \
  --gtest_filter='TestCrypto.hash:TestWord.Simple' \
  --gtest_color=no

"$ROOT/picogram_imp/build/test_basic" \
  --gtest_filter='SwitchStack.*:TestCrypto.hash:TestWord.Simple' \
  --gtest_color=no

"$ROOT/artifact/scripts/run_merge_benchmark.sh" \
  --rounds 3 \
  --outdir "$ROOT/artifact_results/quick_merge"

python3 "$ROOT/run_picogram_compare.py" \
  --projects picogram picogram_imp \
  --min-exp 5 \
  --max-exp 5 \
  --seed 1 \
  --outdir artifact_results/quick_picogram

echo "[quick_check] complete"
echo "[quick_check] merge logs: $ROOT/artifact_results/quick_merge"
echo "[quick_check] PicoGRAM comparison: $ROOT/artifact_results/quick_picogram"
