#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
ROUNDS=4
PORT=12345
OUTDIR="$ROOT/artifact_results/merge"
MODE="both"
WORD_WIDTH=32
EMP_PREFIX="${EMP_TOOL_ROOT:-$HOME/libs}"

export EMP_TOOL_ROOT="$EMP_PREFIX"
export LD_LIBRARY_PATH="$EMP_PREFIX/lib:${LD_LIBRARY_PATH:-}"

usage() {
  cat <<'USAGE'
Usage: artifact/scripts/run_merge_benchmark.sh [options]

Options:
  --rounds N       Number of size doublings to run (default: 4; full paper path: 12)
  --port P         First localhost TCP port (default: 12345)
  --outdir DIR     Output directory (default: artifact_results/merge)
  --mode MODE      ours, baseline, or both (default: both)
  --word-width W   Word width passed to the binaries (default: 32)
USAGE
}

while [ "$#" -gt 0 ]; do
  case "$1" in
    --rounds) ROUNDS="$2"; shift 2 ;;
    --port) PORT="$2"; shift 2 ;;
    --outdir) OUTDIR="$2"; shift 2 ;;
    --mode) MODE="$2"; shift 2 ;;
    --word-width) WORD_WIDTH="$2"; shift 2 ;;
    -h|--help) usage; exit 0 ;;
    *) echo "unknown option: $1" >&2; usage >&2; exit 2 ;;
  esac
done

if [ ! -x "$ROOT/build/garbler" ] || [ ! -x "$ROOT/build/evaluator" ]; then
  "$ROOT/artifact/scripts/build_all.sh"
fi

mkdir -p "$OUTDIR"

run_pair() {
  local label="$1"
  local port="$2"
  shift 2
  local gar_log="$OUTDIR/${label}_garbler.log"
  local eva_log="$OUTDIR/${label}_evaluator.log"

  echo "[merge] running $label on localhost:$port for $ROUNDS rounds"
  "$ROOT/build/garbler" -p "$port" -n 1 -m 1 -w "$WORD_WIDTH" -rounds "$ROUNDS" "$@" \
    >"$gar_log" 2>&1 &
  local garbler_pid=$!
  sleep 1

  if ! "$ROOT/build/evaluator" -i 127.0.0.1 -p "$port" -n 1 -m 1 -w "$WORD_WIDTH" -rounds "$ROUNDS" "$@" \
    >"$eva_log" 2>&1; then
    wait "$garbler_pid" || true
    echo "[merge] evaluator failed; see $eva_log" >&2
    exit 1
  fi

  if ! wait "$garbler_pid"; then
    echo "[merge] garbler failed; see $gar_log" >&2
    exit 1
  fi
}

case "$MODE" in
  ours)
    run_pair ours "$PORT"
    ;;
  baseline)
    run_pair baseline "$PORT" -base
    ;;
  both)
    run_pair ours "$PORT"
    run_pair baseline "$((PORT + 1))" -base
    ;;
  *)
    echo "invalid mode: $MODE" >&2
    exit 2
    ;;
esac

if [ -f "$OUTDIR/ours_garbler.log" ]; then
  cp "$OUTDIR/ours_garbler.log" "$OUTDIR/switch.txt"
fi
if [ -f "$OUTDIR/baseline_garbler.log" ]; then
  cp "$OUTDIR/baseline_garbler.log" "$OUTDIR/bool.txt"
fi
if [ -f "$OUTDIR/ours_evaluator.log" ]; then
  cp "$OUTDIR/ours_evaluator.log" "$OUTDIR/switch_com.txt"
fi
if [ -f "$OUTDIR/baseline_evaluator.log" ]; then
  cp "$OUTDIR/baseline_evaluator.log" "$OUTDIR/bool_com.txt"
  cp "$OUTDIR/baseline_evaluator.log" "$OUTDIR/simd.txt"
fi

if [ -f "$OUTDIR/bool.txt" ] && [ -f "$OUTDIR/simd.txt" ] && [ -f "$OUTDIR/switch.txt" ]; then
  python3 "$ROOT/export.py" \
    --dir "$OUTDIR" \
    --out "$OUTDIR/merge_communication.csv" \
    --min-exp 1 \
    --max-exp "$ROUNDS" \
    --word-width "$WORD_WIDTH"
fi

echo "[merge] wrote logs to $OUTDIR"
