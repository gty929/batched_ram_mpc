#!/usr/bin/env python3
"""
Export non_ob_stack-style merge benchmark logs into a "wide" CSV.

Input files (default under ./build):
  - bool.txt   : lines like "[G-CompNet-Payload] ... nonOT_bits=..."
  - simd.txt   : lines like "[E-P256-SIMD] ... total_bits=..."
  - switch.txt : lines like "[G] ... Payload=..."

Output CSV format:
  type,wordwidth,2^1,2^2,...,2^11

The CSV reports the actual word width used for the benchmark run.
"""

from __future__ import annotations

import argparse
import csv
import re
from pathlib import Path
from typing import Dict, Optional


_KV_RE = re.compile(r"([A-Za-z0-9_]+)=([0-9.+-eE]+)")

_REPLACEMENTS = (
    ("total bits=", "total_bits="),
    ("Communication (bits)=", "Communication_bits="),
    ("rows(sent)=", "rows_sent="),
    ("pairs/pass=", "pairs_pass="),
    ("ANDs(struct)=", "ANDs_struct="),
)


def _parse_kv(line: str) -> Dict[str, str]:
    s = line
    for old, new in _REPLACEMENTS:
        s = s.replace(old, new)
    return dict(_KV_RE.findall(s))


def _log2_pow2(n: int) -> Optional[int]:
    if n <= 0:
        return None
    if n & (n - 1):
        return None
    return n.bit_length() - 1


def _parse_series(path: Path, kind: str, min_exp: int, max_exp: int) -> Dict[int, int]:
    """
    Returns {exp -> bits} where exp is such that N == 2^exp.
    """
    out: Dict[int, int] = {}
    for raw in path.read_text().splitlines():
        line = raw.strip()
        if not line:
            continue
        kv = _parse_kv(line)

        # Extract the communication field of interest.
        if kind == "bool":
            if "nonOT_bits" not in kv:
                continue
            bits = int(float(kv["nonOT_bits"]))
        elif kind == "simd":
            if "total_bits" not in kv:
                continue
            bits = int(float(kv["total_bits"]))
        elif kind == "switch":
            if "Payload" not in kv:
                continue
            bits = int(float(kv["Payload"]))
        else:
            raise ValueError(f"unknown kind: {kind}")

        # Determine N.
        if "N" in kv:
            N = int(float(kv["N"]))
        elif "n" in kv and "m" in kv:
            N = int(float(kv["n"])) + int(float(kv["m"]))
        else:
            continue

        exp = _log2_pow2(N)
        if exp is None:
            continue
        if exp < min_exp or exp > max_exp:
            continue
        out[exp] = bits  # keep last occurrence
    return out


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument(
        "--dir",
        type=Path,
        default=Path("build"),
        help="Directory containing bool.txt/simd.txt/switch.txt (default: ./build).",
    )
    ap.add_argument(
        "--bool",
        type=Path,
        default=None,
        help="Override path to bool.txt.",
    )
    ap.add_argument(
        "--simd",
        type=Path,
        default=None,
        help="Override path to simd.txt.",
    )
    ap.add_argument(
        "--switch",
        type=Path,
        default=None,
        help="Override path to switch.txt.",
    )
    ap.add_argument(
        "--out",
        type=Path,
        default=Path("comm_cost_figures.csv"),
        help="Output CSV path (default: ./comm_cost_figures.csv).",
    )
    ap.add_argument("--min-exp", type=int, default=1, help="Minimum exponent (default: 1).")
    ap.add_argument("--max-exp", type=int, default=11, help="Maximum exponent (default: 11).")
    ap.add_argument(
        "--word-width",
        type=int,
        default=32,
        help="Word width used in the benchmark run (default: 32).",
    )
    args = ap.parse_args()

    bool_path = args.bool or (args.dir / "bool.txt")
    simd_path = args.simd or (args.dir / "simd.txt")
    switch_path = args.switch or (args.dir / "switch.txt")

    missing = [p for p in (bool_path, simd_path, switch_path) if not p.exists()]
    if missing:
        raise SystemExit(f"Missing input files: {', '.join(str(p) for p in missing)}")

    series_bool = _parse_series(bool_path, "bool", args.min_exp, args.max_exp)
    series_simd = _parse_series(simd_path, "simd", args.min_exp, args.max_exp)
    series_switch = _parse_series(switch_path, "switch", args.min_exp, args.max_exp)

    kinds = [("bool", series_bool), ("switch", series_switch), ("simd", series_simd)]
    exps = list(range(args.min_exp, args.max_exp + 1))

    with args.out.open("w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["type", "wordwidth"] + [f"2^{e}" for e in exps])
        for kind, series in kinds:
            row = [kind, str(args.word_width)]
            for e in exps:
                base = series.get(e)
                row.append("" if base is None else str(base))
            w.writerow(row)

    print(f"Wrote {args.out}")


if __name__ == "__main__":
    main()
