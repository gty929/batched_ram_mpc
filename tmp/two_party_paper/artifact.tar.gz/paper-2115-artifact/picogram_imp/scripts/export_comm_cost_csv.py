#!/usr/bin/env python3
"""
Export the communication-cost inputs used by scripts/plot.py into a single CSV.

This is intentionally dependency-free (stdlib only) so it can run in constrained
environments.
"""

from __future__ import annotations

import csv
import math
import re
from pathlib import Path
from typing import Dict, Optional


_NUM_RE = re.compile(r"[-+]?\d*\.\d+|\d+")


def _parse_float(line: str) -> float:
    m = _NUM_RE.findall(line)
    if not m:
        raise ValueError(f"no numeric value found in line: {line!r}")
    return float(m[0])


def parse_cost_file(path: Path) -> Dict[int, dict]:
    """
    Parse a file in the format of scripts/simd_raw.txt / scripts/tsc_raw.txt /
    scripts/switch.txt.

    Returns a dict keyed by T with fields:
      - gc_MB_per_access
      - stack_MB_per_access
      - tsc_stack_MB_per_access (optional)
    """
    by_T: Dict[int, dict] = {}
    current_T: Optional[int] = None

    for raw_line in path.read_text().splitlines():
        line = raw_line.strip()
        if not line:
            continue

        if line.startswith("T:"):
            current_T = int(line.split(":", 1)[1].strip())
            by_T.setdefault(current_T, {})
            continue

        if current_T is None:
            continue

        if line.startswith("gc size:"):
            gb = _parse_float(line)
            by_T[current_T]["gc_MB_per_access"] = gb / current_T * 1024.0
            continue

        if line.startswith("stack cost:"):
            gb = _parse_float(line)
            by_T[current_T]["stack_MB_per_access"] = gb / current_T * 1024.0
            continue

        if line.startswith("tsc stack cost:"):
            gb = _parse_float(line)
            by_T[current_T]["tsc_stack_MB_per_access"] = gb / current_T * 1024.0
            continue

    return by_T


def _stack_fraction(stack: Optional[float], total: Optional[float]) -> Optional[float]:
    if stack is None or total is None:
        return None
    if total == 0:
        return None
    return stack / total


def _format(v: Optional[float]) -> str:
    if v is None:
        return ""
    # Keep enough precision for plots while staying readable.
    return f"{v:.9g}"


def main() -> None:
    scripts_dir = Path(__file__).resolve().parent

    # Files used by scripts/plot.py for communication-cost plots.
    picogram = parse_cost_file(scripts_dir / "simd_raw.txt")
    pico_no_simd = parse_cost_file(scripts_dir / "tsc_raw.txt")
    ours = parse_cost_file(scripts_dir / "switch.txt")

    # Nanogram simulator series (bytes), embedded in scripts/plot.py.
    # We export them so all plot inputs live in one CSV.
    nanogram_bytes = [
        26784883.0,
        41147730.0,
        52213399.0,
        70949099.0,
        86272094.0,
        112710067.0,
        137789392.0,
        174707282.0,
        202730838.0,
        250616114.0,
        286213645.0,
        350803724.0,
        396293071.0,
        470804247.0,
        526104771.0,
        616127709.0,
    ]
    nanogram_boolean_bytes = [
        21532309.0,
        31582984.0,
        39292466.0,
        52140508.0,
        62970761.0,
        80793786.0,
        99679755.0,
        124698495.0,
        144507991.0,
        176653024.0,
        201695783.0,
        246147646.0,
        278421531.0,
        327839644.0,
        366944043.0,
        426362198.0,
    ]
    # plot.py uses T = [2**i for i in range(10,25)] (i.e. 2^10..2^24 inclusive).
    # The nanogram arrays include 16 points; we export whichever points overlap.
    nanogram_logN0 = 10

    all_T = sorted(set(picogram.keys()) | set(pico_no_simd.keys()) | set(ours.keys()))

    out_path = scripts_dir / "comm_cost_figures.csv"

    with out_path.open("w", newline="") as f:
        w = csv.writer(f)
        w.writerow(
            [
                "logN",
                "T",
                "pico_no_simd_total_MB",
                "pico_no_simd_stack_MB",
                "pico_no_simd_stack_frac",
                "picogram_total_MB",
                "picogram_stack_MB",
                "picogram_stack_frac",
                "ours_total_MB",
                "ours_stack_MB",
                "ours_stack_frac",
                "nanogram_total_MB",
                "nanogram_boolean_MB",
                "nanogram_stack_MB",
                "nanogram_stack_frac",
            ]
        )

        for T in all_T:
            logN = math.log2(T) if T > 0 else float("nan")

            pns_total = pico_no_simd.get(T, {}).get("gc_MB_per_access")
            pns_stack = pico_no_simd.get(T, {}).get("stack_MB_per_access")

            pico_total = picogram.get(T, {}).get("gc_MB_per_access")
            pico_stack = picogram.get(T, {}).get("stack_MB_per_access")

            ours_total = ours.get(T, {}).get("gc_MB_per_access")
            ours_stack = ours.get(T, {}).get("stack_MB_per_access")

            # Nanogram series is indexed by logN; include only when available.
            nano_total = None
            nano_bool = None
            if float(logN).is_integer():
                idx = int(logN) - nanogram_logN0
                if 0 <= idx < len(nanogram_bytes):
                    nano_total = nanogram_bytes[idx] / (8 * 1024 * 1024)
                if 0 <= idx < len(nanogram_boolean_bytes):
                    nano_bool = nanogram_boolean_bytes[idx] / (8 * 1024 * 1024)
            nano_stack = None
            if nano_total is not None and nano_bool is not None:
                nano_stack = nano_total - nano_bool

            w.writerow(
                [
                    _format(logN),
                    str(T),
                    _format(pns_total),
                    _format(pns_stack),
                    _format(_stack_fraction(pns_stack, pns_total)),
                    _format(pico_total),
                    _format(pico_stack),
                    _format(_stack_fraction(pico_stack, pico_total)),
                    _format(ours_total),
                    _format(ours_stack),
                    _format(_stack_fraction(ours_stack, ours_total)),
                    _format(nano_total),
                    _format(nano_bool),
                    _format(nano_stack),
                    _format(_stack_fraction(nano_stack, nano_total)),
                ]
            )

    print(f"Wrote {out_path}")


if __name__ == "__main__":
    main()

