#!/usr/bin/env python3
"""
Run RecORAM tests, parse gc/stack cost, and plot amortized cost-per-access
and simulated end-to-end time under various bandwidths (OT excluded).

Usage:
  python3 scripts/run_rec_oram_switch.py --build-dir build \
      --filter "*RecORAM*IncrMeasure*" \
      --bandwidths 10 100 1000 \
      --output plot.png
"""

import argparse
import re
import subprocess
from pathlib import Path
from typing import List, Tuple

import matplotlib.pyplot as plt


def run_test(test_bin: Path, gtest_filter: str, timeout: int) -> str:
    """Run the gtest binary with the given filter and return stdout."""
    cmd = [str(test_bin), f"--gtest_filter={gtest_filter}"]
    print(f"Running: {' '.join(cmd)} (timeout={timeout}s)")
    proc = subprocess.run(
        cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=timeout, text=True
    )
    print(proc.stdout)
    return proc.stdout


def parse_measure_output(output: str) -> Tuple[int, float, float]:
    """Parse T, gc size (bytes), and stack cost (bytes) from MEASURE output."""
    T = None
    gc_bytes = None
    stack_bytes = None
    for line in output.splitlines():
        line = line.strip()
        if line.startswith("T:"):
            try:
                T = int(line.split(":")[1].strip())
            except Exception:
                pass
        elif line.startswith("gc size:"):
            # Line format: "gc size: <val> GB/MB/KB"
            parts = line.split()
            if len(parts) >= 3:
                val = float(parts[2])
                unit = parts[3] if len(parts) >= 4 else "GB"
                if "GB" in unit:
                    gc_bytes = val * (1 << 30)
                elif "MB" in unit:
                    gc_bytes = val * (1 << 20)
                elif "KB" in unit:
                    gc_bytes = val * (1 << 10)
        elif line.startswith("stack cost:"):
            parts = line.split()
            if len(parts) >= 3:
                val = float(parts[2])
                unit = parts[3] if len(parts) >= 4 else "GB"
                if "GB" in unit:
                    stack_bytes = val * (1 << 30)
                elif "MB" in unit:
                    stack_bytes = val * (1 << 20)
                elif "KB" in unit:
                    stack_bytes = val * (1 << 10)
    if T is None or gc_bytes is None or stack_bytes is None:
        raise ValueError("Failed to parse T/gc size/stack cost from output.")
    return T, gc_bytes, stack_bytes


def simulate_times(
    gc_bits: float, num_accesses: int, bandwidths_mbps: List[float]
) -> List[float]:
    """Return amortized time per access (seconds) for given bandwidths (Mbps)."""
    times = []
    for bw in bandwidths_mbps:
        bw_bps = bw * 1e6 / 8.0  # Mbps -> bytes/sec
        comm_time = gc_bits / bw_bps
        times.append(comm_time / num_accesses)
    return times


def plot_results(
    bandwidths: List[float],
    times: List[float],
    cost_bits_per_access: float,
    out_path: Path,
) -> None:
    plt.figure(figsize=(6, 4))
    plt.plot(bandwidths, times, marker="o")
    plt.xlabel("Bandwidth (Mbps)")
    plt.ylabel("Amortized time per access (sec) [OT excluded]")
    plt.title(f"Switch-stack cost per access: {cost_bits_per_access/1e6:.2f} Mb")
    plt.grid(True, linestyle="--", alpha=0.5)
    plt.tight_layout()
    plt.savefig(out_path)
    print(f"Wrote plot to {out_path}")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--build-dir", default="build", help="CMake build directory (default: build)"
    )
    parser.add_argument(
        "--filter",
        default="*RecORAM*IncrMeasure*",
        help="gtest filter to run (use MEASURE variant)",
    )
    parser.add_argument(
        "--bandwidths",
        type=float,
        nargs="+",
        default=[10, 100, 1000],
        help="Bandwidths in Mbps to simulate (default: 10 100 1000)",
    )
    parser.add_argument(
        "--timeout",
        type=int,
        default=3600,
        help="Timeout for the test run in seconds (default: 3600)",
    )
    parser.add_argument(
        "--output",
        type=Path,
        default=Path("rec_oram_switch.png"),
        help="Output plot path",
    )
    args = parser.parse_args()

    test_bin = Path(args.build_dir) / "test_basic"
    if not test_bin.exists():
        raise FileNotFoundError(f"Test binary not found: {test_bin}")

    output = run_test(test_bin, args.filter, args.timeout)
    T, gc_bytes, stack_bytes = parse_measure_output(output)
    num_accesses = T  # RecORAM test runs T timesteps/accesses
    gc_bits = gc_bytes * 8.0
    stack_bits = stack_bytes * 8.0
    cost_per_access_bits = gc_bits / num_accesses
    stack_per_access_bits = stack_bits / num_accesses

    print(f"T={T}")
    print(f"GC size bytes: {gc_bytes:.3f}  (per access: {cost_per_access_bits:.3f} bits)")
    print(f"Stack bytes:   {stack_bytes:.3f}  (per access: {stack_per_access_bits:.3f} bits)")

    times = simulate_times(gc_bits, num_accesses, args.bandwidths)
    for bw, t in zip(args.bandwidths, times):
        print(f"Bandwidth {bw} Mbps -> {t:.6f} sec/access (OT excluded)")

    plot_results(args.bandwidths, times, cost_per_access_bits, args.output)


if __name__ == "__main__":
    main()
