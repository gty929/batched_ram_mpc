#!/usr/bin/env python3
"""
Run RecORAM communication tests for switch-stack (COND) from 2^10 to 2^20,
parse per-access costs, and plot against the baseline SIMDinlined data
in scripts/simd_raw.txt.

This script expects:
  - build/test_basic compiled
  - matplotlib installed (use a venv if needed)

Example:
  python3 scripts/run_switch_range.py --build-dir build --output switch_vs_baseline.png
"""

import argparse
import os
import subprocess
from pathlib import Path
from typing import List, Optional

import matplotlib.pyplot as plt

from parse_raw import parse_amortized_cost


def run_comm_single(test_bin: Path, n: int, timeout: int) -> Optional[str]:
    """Run a single N; return stdout or None on timeout."""
    env = os.environ.copy()
    env["REC_ORAM_MIN_N"] = str(n)
    env["REC_ORAM_MAX_N"] = str(n)
    cmd = [str(test_bin), "--gtest_filter=RecORAM.IncrPerfSIMDCommCost"]
    print(f"Running {' '.join(cmd)} with N={n}")
    try:
        proc = subprocess.run(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            env=env,
            text=True,
            timeout=timeout,
        )
        print(proc.stdout)
        return proc.stdout
    except subprocess.TimeoutExpired:
        print(f"Timed out for N={n}, skipping.")
        return None


def parse_measured(output: str):
    # parse_amortized_cost expects a file; feed via temp approach
    from tempfile import NamedTemporaryFile

    with NamedTemporaryFile("w+", delete=False) as tmp:
        tmp.write(output)
        tmp.flush()
        gc, stack, _ = parse_amortized_cost(tmp.name)
    return gc, stack


def plot_comparison(Ts: List[int], switch_mb: List[float], baseline_mb: List[float], out: Path):
    plt.figure(figsize=(6, 4))
    plt.plot([t.bit_length() - 1 for t in Ts], switch_mb, marker="o", label="Switch stack (COND)")
    plt.plot(range(10, 10 + len(baseline_mb)), baseline_mb, marker="s", label="SIMD baseline (simd_raw)")
    plt.xlabel("log2 N")
    plt.ylabel("Cost per access (MB)")
    plt.title("RecORAM communication per access (OT excluded)")
    plt.legend()
    plt.grid(True, linestyle="--", alpha=0.5)
    plt.tight_layout()
    plt.savefig(out)
    print(f"Wrote plot to {out}")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--build-dir", default="build", help="Path to build dir (default: build)")
    parser.add_argument("--min-exp", type=int, default=10, help="Min exponent for N=2^exp (default 10)")
    parser.add_argument("--max-exp", type=int, default=20, help="Max exponent for N=2^exp (default 20)")
    parser.add_argument("--timeout", type=int, default=3600, help="Timeout per run (default 3600s)")
    parser.add_argument("--output", type=Path, default=Path("switch_vs_baseline.png"), help="Output plot path")
    parser.add_argument(
        "--log",
        type=Path,
        help="Optional existing log file; if set, skip running tests and parse this log instead.",
    )
    args = parser.parse_args()

    switch_gc: List[float] = []
    switch_stack: List[float] = []
    Ts: List[int] = []

    if args.log:
        if not args.log.exists():
            raise FileNotFoundError(f"Log file not found: {args.log}")
        gc_mb, stack_mb, _ = parse_amortized_cost(str(args.log))
        # T values are inferred from length; assume start at min-exp
        Ts = [1 << (args.min_exp + i) for i in range(len(gc_mb))]
        switch_gc = gc_mb.tolist()
        switch_stack = stack_mb.tolist() if len(stack_mb) else [0.0] * len(gc_mb)
    else:
        test_bin = Path(args.build_dir) / "test_basic"
        if not test_bin.exists():
            raise FileNotFoundError(f"Missing test binary: {test_bin}")

        for exp in range(args.min_exp, args.max_exp + 1):
            n = 1 << exp
            out = run_comm_single(test_bin, n, args.timeout)
            if out is None:
                continue
            gc_mb, stack_mb = parse_measured(out)
            if len(gc_mb) == 0:
                continue
            # parse_amortized_cost already outputs per-access MB
            switch_gc.append(gc_mb[0])
            switch_stack.append(stack_mb[0] if len(stack_mb) else 0.0)
            Ts.append(n)

    # parse baseline from simd_raw.txt
    simd_gc_mb, _, _ = parse_amortized_cost(str(Path(__file__).with_name("simd_raw.txt")))

    plot_comparison(Ts, switch_gc, simd_gc_mb.tolist(), args.output)

    print("Parsed GC per-access (MB):", switch_gc)
    print("Parsed stack per-access (MB):", switch_stack)


if __name__ == "__main__":
    main()
