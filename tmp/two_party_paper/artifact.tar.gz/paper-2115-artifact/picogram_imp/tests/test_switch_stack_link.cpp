#include "gadget.hpp"
#include "gadget_group.hpp"
#include "test_util.hpp"

using namespace PicoGRAM;

namespace {

static uint64_t g_group_child_id_counter = 0;

struct SwitchStackGroupChild : Gadget {
  uint64_t id;

  std::function<FuncOutput(FuncInput)> foo_func = [&](FuncInput inputs) {
    Assert_eq(inputs.size(), 1);
    Word mask = Word::constant(self, inputs[0].width(), id);
    return FuncOutput({inputs[0] ^ mask});
  };

  DEFINE_FUNC(foo, {16}, foo_func);

  SwitchStackGroupChild(Gadget* caller, LinkType link_type, uint64_t T_child
#ifdef FAST_MEASURE
                        ,
                        uint64_t measure_multiplier = 1
#endif
                        )
      : Gadget(caller, link_type, T_child
#ifdef FAST_MEASURE
               ,
               measure_multiplier
#endif
               ),
        id(g_group_child_id_counter++) {
    set_name("SwitchStackGroupChild");
  }
};

struct SwitchStackEchoChild : Gadget {
  std::function<FuncOutput(FuncInput)> echo_func = [&](FuncInput inputs) {
    Assert_eq(inputs.size(), 1);
    return FuncOutput({inputs[0]});
  };

  DEFINE_FUNC(echo, {16}, echo_func);

  SwitchStackEchoChild(Gadget* caller, uint64_t T_child)
      : Gadget(caller, COND, T_child) {
    set_name("SwitchStackEchoChild");
  }
};

struct SwitchStackEchoMain : Gadget {
  static constexpr uint kWidth = 16;
  static constexpr uint64_t kTChild = 8;

  SwitchStackEchoChild child;

  std::function<FuncOutput(FuncInput)> main_func = [&](FuncInput) {
    Assert_less(t, 16UL);
    const uint8_t ctrl_val = (t % 2 == 0) ? 0 : 1;  // 8 real, 8 fake
    Bit ctrl = Bit::input_dbg(self, ctrl_val);

    const uint64_t in_val = (t + 1) & ((1UL << kWidth) - 1);
    Word in = Word::input_dbg(self, kWidth, in_val);

    const std::vector<Word>& out = child.echo(ctrl, {in});
    Assert_eq(out.size(), 1);

    const uint8_t ctrl_revealed = ctrl.to_int();
    const uint64_t in_revealed = in.to_int();
    const uint64_t out_revealed = out[0].to_int();
    if (get_mode() == EVAL || get_mode() == DEBUG) {
      if (!ctrl_revealed) {
        EXPECT_EQ(out_revealed, in_revealed);
      }
    }
    return FuncOutput();
  };

  DEFINE_FUNC(main, {}, main_func);

  SwitchStackEchoMain(uint64_t T, Mode mode)
      : Gadget(mode, T), child(this, kTChild) {
    Assert_eq(T, 16UL);
    set_name("SwitchStackEchoMain");
  }
};

struct SwitchStackEchoBurstMain : Gadget {
  static constexpr uint kWidth = 16;
  static constexpr uint64_t kTChild = 8;

  SwitchStackEchoChild child;

  std::function<FuncOutput(FuncInput)> main_func = [&](FuncInput) {
    Assert_less(t, 16UL);
    const uint8_t ctrl_val = (t < 8) ? 1 : 0;  // 8 fake then 8 real
    Bit ctrl = Bit::input_dbg(self, ctrl_val);

    const uint64_t in_val = (t + 1) & ((1UL << kWidth) - 1);
    Word in = Word::input_dbg(self, kWidth, in_val);

    const std::vector<Word>& out = child.echo(ctrl, {in});
    Assert_eq(out.size(), 1);

    const uint8_t ctrl_revealed = ctrl.to_int();
    const uint64_t in_revealed = in.to_int();
    const uint64_t out_revealed = out[0].to_int();
    if (get_mode() == EVAL || get_mode() == DEBUG) {
      if (!ctrl_revealed) {
        EXPECT_EQ(out_revealed, in_revealed);
      }
    }
    return FuncOutput();
  };

  DEFINE_FUNC(main, {}, main_func);

  SwitchStackEchoBurstMain(uint64_t T, Mode mode)
      : Gadget(mode, T), child(this, kTChild) {
    Assert_eq(T, 16UL);
    set_name("SwitchStackEchoBurstMain");
  }
};

struct SwitchStackEchoUnderfullMain : Gadget {
  static constexpr uint kWidth = 16;
  static constexpr uint64_t kTChild = 8;  // upper bound on real calls

  SwitchStackEchoChild child;

  std::function<FuncOutput(FuncInput)> main_func = [&](FuncInput) {
    Assert_less(t, 16UL);
    const uint8_t ctrl_val = (t < 4) ? 0 : 1;  // only 4 real calls (< kTChild)
    Bit ctrl = Bit::input_dbg(self, ctrl_val);

    const uint64_t in_val = (t + 1) & ((1UL << kWidth) - 1);
    Word in = Word::input_dbg(self, kWidth, in_val);

    const std::vector<Word>& out = child.echo(ctrl, {in});
    Assert_eq(out.size(), 1);

    const uint8_t ctrl_revealed = ctrl.to_int();
    const uint64_t out_revealed = out[0].to_int();
    if (get_mode() == EVAL || get_mode() == DEBUG) {
      if (!ctrl_revealed) {
        EXPECT_EQ(out_revealed, in_val);
      }
    }
    return FuncOutput();
  };

  DEFINE_FUNC(main, {}, main_func);

  SwitchStackEchoUnderfullMain(uint64_t T, Mode mode)
      : Gadget(mode, T), child(this, kTChild) {
    Assert_eq(T, 16UL);
    set_name("SwitchStackEchoUnderfullMain");
  }
};

struct SwitchStackGroupMain : Gadget {
  static constexpr uint kWidth = 16;
  static constexpr uint64_t kT = 16;
  static constexpr uint64_t kTChild = 8;

  Group<SwitchStackGroupChild> children;

  std::function<FuncOutput(FuncInput)> main_func = [&](FuncInput) {
    Assert_less(t, kT);
    const uint8_t sel_val = (t % 2);  // balanced: 8 each
    Word sel = Word::input_dbg(self, 1, sel_val);
    GroupEntry<SwitchStackGroupChild> entry = children[sel];

    const uint64_t in_val = (t + 5) & ((1UL << kWidth) - 1);
    Word in = Word::input_dbg(self, kWidth, in_val);

    std::vector<Word> out = entry.call("foo", {in});
    Assert_eq(out.size(), 1);

    const uint64_t out_val = out[0].to_int();
    if (get_mode() == EVAL || get_mode() == DEBUG) {
      const uint64_t expected = in_val ^ (sel_val ? 1 : 0);
      EXPECT_EQ(out_val, expected);
    } else {
      (void)out_val;
    }
    return FuncOutput();
  };

  DEFINE_FUNC(main, {}, main_func);

  SwitchStackGroupMain(uint64_t T, Mode mode)
      : Gadget(mode, T),
        children(this, std::vector<uint64_t>{kTChild, kTChild}) {
    Assert_eq(T, kT);
    set_name("SwitchStackGroupMain");
  }
};

}  // namespace

TEST(SwitchStack, EchoLink) {
  test_gadget<SwitchStackEchoMain>(ANY, {16, 16}, 1024 * 1024 * 16);
}

TEST(SwitchStack, EchoLinkBurst) {
  test_gadget<SwitchStackEchoBurstMain>(ANY, {16, 16}, 1024 * 1024 * 16);
}

TEST(SwitchStack, EchoLinkUnderfull) {
  test_gadget<SwitchStackEchoUnderfullMain>(ANY, {16, 16}, 1024 * 1024 * 16);
}

TEST(SwitchStack, GroupSelect) {
  g_group_child_id_counter = 0;
  test_gadget<SwitchStackGroupMain>(ANY, {16, 16}, 1024 * 1024 * 16);
}
