import re
import matplotlib.pyplot as plt
import matplotlib.font_manager as fm
import matplotlib.ticker as ticker
import numpy as np

fontsize = 30

plt.rcParams["font.family"] = "Times New Roman"
plt.rcParams["legend.fontsize"] = fontsize
plt.rcParams["axes.titlesize"] = fontsize
plt.rcParams["axes.labelsize"] = fontsize
plt.rcParams["xtick.labelsize"] = fontsize
plt.rcParams["ytick.labelsize"] = fontsize

def add_corner_label(ax, text, loc="upper right", fontsize=20):
    pos = {
        "upper right":  (0.98, 0.98, "right", "top"),
        "upper left":   (0.02, 0.98, "left",  "top"),
        "lower right":  (0.98, 0.02, "right", "bottom"),
        "lower left":   (0.02, 0.02, "left",  "bottom"),
    }
    x, y, ha, va = pos[loc]
    ax.text(
        x, y, text,
        transform=ax.transAxes,
        ha=ha, va=va,
        fontsize=fontsize,
        fontweight="bold",
        bbox=dict(boxstyle="round,pad=0.3", fc="white", ec="none", alpha=0.75)
    )



bool_file = "build/bool.txt"
switch_file = "build/switch.txt"
bool_comp_file = "build/bool_com.txt"
switch_comp_file = "build/switch_com.txt"
simd_file = "build/simd.txt"

N_bool, nonOT_bits_128, DDH_bits_128, nonOT_bits_32, DDH_bits_32 = [], [], [], [], []
with open(bool_file, "r") as f:
    for line in f:
        match = re.search(r"N=(\d+).*nonOT_bits=(\d+).*DDH_count=(\d+)", line)
        if match:
            N_bool.append(int(match.group(1)))
            nonOT_bits_128.append(2 * int(match.group(2)) / (8 * 1024))
            nonOT_bits_32.append(0.5 * int(match.group(2)) / (8 * 1024))

with open(simd_file, "r") as f:
    for line in f:
        match = re.search(r"N=(\d+).*switch_bits=(\d+).*grp_bits=(\d+).*ungrp_bits=(\d+).*total_bits=(\d+)", line)
        if match:
            # baseline
            total_bits = int(match.group(5)) + 4 * (int(match.group(3)) + int(match.group(4)))
            DDH_bits_128.append(total_bits / (8 * 1024))
            tb_32 = int(match.group(2)) + (int(match.group(3)) + int(match.group(4)))
            DDH_bits_32.append(tb_32 / (8 * 1024))


N_switch, payload_128, payload_32 = [], [], []
with open(switch_file, "r") as f:
    for line in f:
        match = re.search(r"n=(\d+).*m=(\d+).*Payload=(\d+)", line)
        if match:
            N_switch.append(int(match.group(1)) + int(match.group(2)))
            payload_128.append(4 * int(match.group(3)) / (8 * 1024))
            payload_32.append(int(match.group(3)) / (8 * 1024))

N_vals, hashingcount_b = [], []
with open(bool_comp_file, "r") as f:
    for line in f:
        match_N = re.search(r"N=(\d+)", line)
        if match_N:
            N_vals.append(int(match_N.group(1)))
        match_hash = re.search(r"Hashing count:\s*(\d+)", line)
        if match_hash:
            hashingcount_b.append(int(match_hash.group(1)))

# Extract from switch_comp_file
N_switch_comp, hashingcount_s = [], []
with open(switch_comp_file, "r") as f:
    for line in f:
        match_N = re.search(r"n=(\d+).*m=(\d+)", line)
        if match_N:
            N_switch_comp.append(int(match_N.group(1)) + int(match_N.group(2)))
        match_hash = re.search(r"Hashing count:\s*(\d+)", line)
        if match_hash:
            hashingcount_s.append(int(match_hash.group(1)))

N_switch_co, hash_random = [], []
with open("build/switch_com_rand.txt", "r") as f:
    for line in f:
        match_N = re.search(r"n=(\d+).*m=(\d+)", line)
        if match_N:
            N_switch_co.append(int(match_N.group(1)) + int(match_N.group(2)))
        match_hash = re.search(r"Hashing count deter:\s*(\d+)", line)
        if match_hash:
            hash_random.append(int(match_hash.group(1)))

N_switch_det, hash_deter = [], []
with open("build/switch_com_deter.txt", "r") as f:
    for line in f:
        match_N = re.search(r"n=(\d+).*m=(\d+)", line)
        if match_N:
            N_switch_det.append(int(match_N.group(1)) + int(match_N.group(2)))
        match_hash = re.search(r"Hashing count deter:\s*(\d+)", line)
        if match_hash:
            hash_deter.append(int(match_hash.group(1)))

print(hashingcount_b)
print(hashingcount_s)

# Plot Communication Comparison

plt.figure(figsize=(4,4))
ax1 = plt.gca()

# Common styling
lw_base = 1.8
lw_ours = 2.6
me = 0.08  # fraction of points to mark (works if you use markevery as int; see below)

def markevery_from_len(n, k=10):
    # mark about k points, evenly spaced
    return max(1, n // k)

# Word-size -> linestyle
ls_32  = "-"
ls_128 = "--"

# Algorithm -> marker
m_bool = "o"
m_ddh  = "x"
m_ours = "d"

# (Color deliberately omitted or set to black)
kw_common = dict(color="black", markersize=5, markerfacecolor="white")
plt.grid(False)

# Boolean
plt.plot(N_bool, nonOT_bits_32,linestyle=ls_32, marker=m_bool, linewidth=lw_base,markevery=markevery_from_len(len(N_bool), k=10),label="Boolean Compaction, w=32",color='green')
plt.plot(N_bool, nonOT_bits_128,
         linestyle=ls_128, marker=m_bool, linewidth=lw_base,
         markevery=markevery_from_len(len(N_bool), k=10),color='green',
         label="Boolean Compaction, w=128")

# SIMD (DDH)
plt.plot(N_bool, DDH_bits_32,
         linestyle=ls_32, marker=m_ddh, linewidth=lw_base,
         markevery=markevery_from_len(len(N_bool), k=10),color='orange',
         label="SIMD Compaction, w=32")
plt.plot(N_bool, DDH_bits_128,
         linestyle=ls_128, marker=m_ddh, linewidth=lw_base,
         markevery=markevery_from_len(len(N_bool), k=10),color='orange',
         label="SIMD Compaction, w=128")

# Ours
plt.plot(N_switch, payload_32,
         linestyle=ls_32, marker=m_ours, linewidth=lw_ours,
         markevery=markevery_from_len(len(N_switch), k=10),color='blue',
         label="Our Approach, w=32")
plt.plot(N_switch, payload_128,
         linestyle=ls_128, marker=m_ours, linewidth=lw_ours,
         markevery=markevery_from_len(len(N_switch), k=10),color='blue',
         label="Our Approach, w=128")

# Axes styling
plt.xscale("log", base=2)   # if N is powers of two
plt.yscale("log")           # communication trends are multiplicative
plt.xlabel("N")
plt.ylabel("Communication (bits or MB)")
# plt.grid(True, which="both", linestyle=":", linewidth=0.8)

# Legend: compact, grayscale-friendly
# plt.legend(ncol=2, frameon=False, handlelength=3.0)

plt.xlabel("lg n")
plt.ylabel("Communication Cost (KB)")
plt.legend(
    # ncol=1,              # 2 columns instead of 1
    fontsize=26,         # smaller text
    frameon=False,       # no box
    handlelength=2.2,    # shorter line samples
    handletextpad=0.6,
    # columnspacing=1.2,
    loc="upper left"
)

plt.xscale("log", base=2)
plt.gca().xaxis.set_major_locator(ticker.LogLocator(base=2))
plt.gca().xaxis.set_major_formatter(ticker.FuncFormatter(lambda val, _: int(np.log2(val))))


plt.yscale("log", base=10)

# add_corner_label(ax1, f"w = 128", loc="upper left", fontsize=14)
plt.savefig("communication_comparison_128.png", dpi=300)

# Plot Computation Comparison
plt.figure(figsize=(4,4))
plt.plot(N_vals, hashingcount_b, linestyle="--", marker='o', color='red', label="Boolean Compaction Network")
plt.plot(N_switch_comp, hashingcount_s, linestyle="-", marker='s', color='blue', label="Our Approach")
# plt.plot(N_switch_comp, hash_random, linestyle=":", marker='^', color='purple', label="Our Approach (Randomized)")
# plt.plot(N_switch_co, hash_random, linestyle=":", marker='^', color='purple', label="Randomized")
plt.xlabel("lg n")
plt.ylabel("Hash Function Calls")
plt.legend()

plt.xscale("log", base=2)
plt.gca().xaxis.set_major_locator(ticker.LogLocator(base=2))
plt.gca().xaxis.set_major_formatter(ticker.FuncFormatter(lambda val, _: int(np.log2(val))))

plt.yscale("log", base=10)
# plt.gca().yaxis.set_major_locator(ticker.LogLocator(base=10))
# plt.gca().yaxis.set_major_formatter(ticker.FuncFormatter(lambda val, _: int(np.log10(val))))

plt.savefig("computation_comparison.png", dpi=300)


# plt.figure(figsize=(10,6))
# plt.plot(N_switch_det, hash_deter, linestyle="-", marker='s', color='blue', label="Deterministic")
# plt.plot(N_switch_co, hash_random, linestyle=":", marker='^', color='purple', label="Randomized")
# plt.xlabel("N")
# plt.ylabel("Hashing Count")
# plt.title("Comparison of Computation Cost")
# plt.legend()
# plt.xscale("log", base=2)
# plt.gca().xaxis.set_major_locator(ticker.LogLocator(base=2))
# plt.gca().xaxis.set_major_formatter(ticker.FuncFormatter(lambda val, _: int(np.log2(val))))
# plt.yscale("log", base=10)

# plt.savefig("computation_deter_vs_rand.png", dpi=300)


