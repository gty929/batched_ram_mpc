#!/usr/bin/env bash
set -euo pipefail

PREFIX="${EMP_TOOL_ROOT:-$HOME/libs}"
EMP_TOOL_REF="${EMP_TOOL_REF:-8052d95ddf56b519a671b774865bb13157b3b4e0}"
EMP_OT_REF="${EMP_OT_REF:-93b7aa9d6d945e2aa43dcab787549ece1f3f1c49}"
SRC="$PREFIX/src"

mkdir -p "$SRC" "$PREFIX/bin" "$PREFIX/lib" "$PREFIX/include"

find . -name "._*" -delete
find . -name ".DS_Store" -delete

if [ "${SKIP_APT:-0}" != "1" ]; then
  echo "[setup] Installing Ubuntu packages"
  if [ "$(id -u)" -eq 0 ]; then
    APT=(apt-get)
  elif command -v sudo >/dev/null 2>&1; then
    APT=(sudo apt-get)
  else
    echo "[setup] sudo not found. Install system packages manually or rerun with SKIP_APT=1." >&2
    exit 1
  fi
  "${APT[@]}" update
  "${APT[@]}" install -y \
    build-essential \
    cmake \
    git \
    libboost-stacktrace-dev \
    libgmp-dev \
    libomp-dev \
    libssl-dev \
    ninja-build \
    pkg-config \
    python3 \
    python3-pip \
    wget
else
  echo "[setup] SKIP_APT=1; assuming Ubuntu build packages are already installed"
fi

echo "[setup] Installing emp-tool into $PREFIX"
if [ ! -d "$SRC/emp-tool/.git" ]; then
  git clone https://github.com/emp-toolkit/emp-tool.git "$SRC/emp-tool"
fi

git -C "$SRC/emp-tool" fetch --tags origin
git -C "$SRC/emp-tool" checkout "$EMP_TOOL_REF"

cmake -S "$SRC/emp-tool" -B "$SRC/emp-tool/build" \
  -DCMAKE_BUILD_TYPE=Release \
  -DCMAKE_INSTALL_PREFIX="$PREFIX"
cmake --build "$SRC/emp-tool/build" --target emp-tool -j"$(nproc)"
cmake --install "$SRC/emp-tool/build"

echo "[setup] Installing emp-ot headers into $PREFIX"
if [ ! -d "$SRC/emp-ot/.git" ]; then
  git clone https://github.com/emp-toolkit/emp-ot.git "$SRC/emp-ot"
fi

git -C "$SRC/emp-ot" fetch --tags origin
git -C "$SRC/emp-ot" checkout "$EMP_OT_REF"

cmake -S "$SRC/emp-ot" -B "$SRC/emp-ot/build" \
  -DCMAKE_BUILD_TYPE=Release \
  -DCMAKE_INSTALL_PREFIX="$PREFIX" \
  -DCMAKE_PREFIX_PATH="$PREFIX"
cmake --install "$SRC/emp-ot/build"

echo "[setup] Done"
echo "[setup] For non-default prefixes, run:"
echo "export EMP_TOOL_ROOT=$PREFIX"
echo "export CMAKE_PREFIX_PATH=$PREFIX"
echo "export LD_LIBRARY_PATH=$PREFIX/lib:\${LD_LIBRARY_PATH:-}"
